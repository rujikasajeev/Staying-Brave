package com.rujikasajeev.stayingbrave247;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class MenuSetActivity extends AppCompatActivity {

    private List<MenuData> menuList = new ArrayList<>();
    private RecyclerView recyclerView;
    private MenuAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_set);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        Intent intent = getIntent();

        mAdapter = new MenuAdapter((ArrayList<MenuData>)menuList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL, 16));
        recyclerView.setAdapter(mAdapter);


        recyclerView.addOnItemTouchListener(new TouchListener(getApplicationContext(), recyclerView, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {


                switch (position) {
                    case 0:
                        Intent intent1 = new Intent(MenuSetActivity.this, emergency_contact.class);
                        startActivity(intent1);
                        break;
                    case 1:
                        Intent intent2 = new Intent(MenuSetActivity.this, Message.class);
                        startActivity(intent2);
                        break;
                    case 2:
                        Intent intent3 = new Intent(MenuSetActivity.this, Message.class);
                        startActivity(intent3);
                        break;
                    case 3:
                        Intent intent4 = new Intent(MenuSetActivity.this, Message.class);
                        startActivity(intent4);
                        break;
                }


            }

            @Override
            public void onLongItemClick(View view, int position) {

            }


        }));

        prepareSupportData();
    }





     void prepareSupportData() {
        MenuData menu = new MenuData("Emergency Contacts");
        menuList.add(menu);

        menu = new MenuData("Police Stations");
        menuList.add(menu);

        menu = new MenuData("Profile");
        menuList.add(menu);

        menu = new MenuData("Message");
        menuList.add(menu);


        mAdapter.notifyDataSetChanged();
    }

}