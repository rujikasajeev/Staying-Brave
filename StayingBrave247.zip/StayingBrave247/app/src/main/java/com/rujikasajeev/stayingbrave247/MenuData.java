package com.rujikasajeev.stayingbrave247;

/**
 * Created by pc on 3/10/2018.
 */

public class MenuData {

    private String title;

    public MenuData() {
    }

    public MenuData(String title) {
        this.title = title;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }

}
